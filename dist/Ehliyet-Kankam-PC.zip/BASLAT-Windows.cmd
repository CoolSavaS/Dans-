@echo off
set "APP=%~dp0Ehliyet-Kankam-UK.html"
set "URL=file:///%APP:\=/%"
where msedge >nul 2>&1 && (start "" msedge --app="%URL%" & goto :eof)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="%URL%" & goto :eof)
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="%URL%" & goto :eof)
start "" "%URL%"
