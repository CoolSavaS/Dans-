#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
URL="file://$DIR/Ehliyet-Kankam-UK.html"
open -a "Google Chrome" --args --app="$URL" 2>/dev/null || open -a "Microsoft Edge" --args --app="$URL" 2>/dev/null || open "$URL"
