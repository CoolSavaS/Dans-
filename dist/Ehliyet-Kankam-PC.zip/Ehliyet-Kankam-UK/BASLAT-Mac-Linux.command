#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
open "$DIR/index.html" 2>/dev/null || xdg-open "$DIR/index.html"
